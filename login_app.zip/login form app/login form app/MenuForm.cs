﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace login_form_app
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=EXPERTAA\SQLEXPRESS;Initial Catalog=""Magazin Hitmarker"";Integrated Security=True;Encrypt=False;Trust Server Certificate=True");

        private void MenuForm_Load(object sender, EventArgs e)
        {
            
        }

    }
}
