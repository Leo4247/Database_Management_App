﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_form_app
{
    public partial class MenuFormcs : Form
    {
        public MenuFormcs()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=EXPERTAA\SQLEXPRESS;Initial Catalog=""Magazin Hitmarker"";Integrated Security=True;Encrypt=False;Trust Server Certificate=True");

        private void MenuFormcs_Load(object sender, EventArgs e)
        {
            FillDGV();
        }
        private void FillDGV()
        {
            conn.Open();
            String querry = "SELECT * FROM Angajati";
            SqlDataAdapter sda = new SqlDataAdapter(querry, conn);
            DataTable dtable = new DataTable();
            sda.Fill(dtable);
            dataGridView1.DataSource = dtable;
            conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FillDGV();
        }
    }
}
