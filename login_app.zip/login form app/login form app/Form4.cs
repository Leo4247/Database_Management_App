﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_form_app
{
    public partial class Form4 : Form
    {
        public string selectedValue;
        public Form4()
        {
            InitializeComponent();
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=EXPERTAA\BD;Initial Catalog=""Magazin Hitmarker"";Integrated Security=True;Encrypt=False;Trust Server Certificate=True");

        private void button7_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedValue = comboBox1.SelectedItem.ToString();
        }


        private void Modify(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                try
                {
                    conn.Open();
                    String query = "SELECT * FROM " + value + " ";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Modify(selectedValue);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_column.Text) && !string.IsNullOrEmpty(text_insert.Text))
            {
                try
                {
                    conn.Open();
                    String query = "INSERT INTO " + selectedValue + " (" + text_column.Text + ") VALUES (" + text_insert.Text + ")";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                Modify(selectedValue);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_column1.Text) && !string.IsNullOrEmpty(text_update.Text) && !string.IsNullOrEmpty(text_update_ID.Text))
            {
                try
                {
                    conn.Open();
                    String query = "UPDATE " + selectedValue + " SET " + text_column1.Text + " = '" + text_update.Text + "' Where " + selectedValue + "ID = " + text_update_ID.Text + "";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }

                Modify(selectedValue);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_delete.Text) && !string.IsNullOrEmpty(selectedValue))
            {
                try
                {
                    conn.Open();
                    String query = " DELETE FROM "+selectedValue+" WHERE "+selectedValue+"ID = "+ text_delete.Text +"";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }

                Modify(selectedValue);
            }
        }
    }
}
