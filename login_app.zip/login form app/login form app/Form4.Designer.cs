﻿namespace login_form_app
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button7 = new Button();
            comboBox1 = new ComboBox();
            text_insert = new TextBox();
            text_column = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            label4 = new Label();
            label5 = new Label();
            text_column1 = new TextBox();
            text_update = new TextBox();
            label6 = new Label();
            text_update_ID = new TextBox();
            button4 = new Button();
            label8 = new Label();
            text_delete = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 27);
            label1.Name = "label1";
            label1.Size = new Size(175, 21);
            label1.TabIndex = 0;
            label1.Text = "Select a table to modify:";
            // 
            // button7
            // 
            button7.Location = new Point(963, 12);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 7;
            button7.Text = "Back";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // comboBox1
            // 
            comboBox1.AllowDrop = true;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Angajat", "Card_Fidelitate", "Categorie", "Furnizor", "Produs", "Raion" });
            comboBox1.Location = new Point(190, 29);
            comboBox1.Name = "comboBox1";
            comboBox1.RightToLeft = RightToLeft.No;
            comboBox1.Size = new Size(154, 23);
            comboBox1.TabIndex = 8;
            comboBox1.Text = "Click arrow to select --->";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // text_insert
            // 
            text_insert.Location = new Point(70, 80);
            text_insert.Name = "text_insert";
            text_insert.PlaceholderText = "Write data to insert into table 'like this', seperated by commas";
            text_insert.Size = new Size(338, 23);
            text_insert.TabIndex = 9;
            // 
            // text_column
            // 
            text_column.Location = new Point(443, 80);
            text_column.Name = "text_column";
            text_column.PlaceholderText = "Write columns here";
            text_column.Size = new Size(118, 23);
            text_column.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 78);
            label2.Name = "label2";
            label2.Size = new Size(52, 21);
            label2.TabIndex = 11;
            label2.Text = "Insert:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(414, 81);
            label3.Name = "label3";
            label3.Size = new Size(23, 21);
            label3.TabIndex = 12;
            label3.Text = "in";
            // 
            // button1
            // 
            button1.Location = new Point(577, 82);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 13;
            button1.Text = "INSERT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.Location = new Point(362, 29);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 14;
            button2.Text = "Show table";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 181);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(1026, 483);
            dataGridView1.TabIndex = 15;
            // 
            // button3
            // 
            button3.Location = new Point(593, 110);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 20;
            button3.Text = "UPDATE";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(246, 109);
            label4.Name = "label4";
            label4.Size = new Size(23, 21);
            label4.TabIndex = 19;
            label4.Text = "in";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(12, 107);
            label5.Name = "label5";
            label5.Size = new Size(63, 21);
            label5.TabIndex = 18;
            label5.Text = "Update:";
            label5.Click += label5_Click;
            // 
            // text_column1
            // 
            text_column1.Location = new Point(275, 109);
            text_column1.Name = "text_column1";
            text_column1.PlaceholderText = "Write column here";
            text_column1.Size = new Size(108, 23);
            text_column1.TabIndex = 17;
            // 
            // text_update
            // 
            text_update.Location = new Point(81, 109);
            text_update.Name = "text_update";
            text_update.PlaceholderText = "Write data to update in table";
            text_update.Size = new Size(159, 23);
            text_update.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(392, 109);
            label6.Name = "label6";
            label6.Size = new Size(53, 21);
            label6.TabIndex = 21;
            label6.Text = "where";
            // 
            // text_update_ID
            // 
            text_update_ID.Location = new Point(451, 111);
            text_update_ID.Name = "text_update_ID";
            text_update_ID.PlaceholderText = "Write column ID here";
            text_update_ID.Size = new Size(120, 23);
            text_update_ID.TabIndex = 22;
            // 
            // button4
            // 
            button4.Location = new Point(212, 138);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 27;
            button4.Text = "DELETE";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(12, 136);
            label8.Name = "label8";
            label8.Size = new Size(57, 21);
            label8.TabIndex = 25;
            label8.Text = "Delete:";
            // 
            // text_delete
            // 
            text_delete.Location = new Point(70, 139);
            text_delete.Name = "text_delete";
            text_delete.PlaceholderText = "Write column ID here";
            text_delete.Size = new Size(120, 23);
            text_delete.TabIndex = 28;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1050, 676);
            Controls.Add(text_delete);
            Controls.Add(button4);
            Controls.Add(label8);
            Controls.Add(text_update_ID);
            Controls.Add(label6);
            Controls.Add(button3);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(text_column1);
            Controls.Add(text_update);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(text_column);
            Controls.Add(text_insert);
            Controls.Add(comboBox1);
            Controls.Add(button7);
            Controls.Add(label1);
            Name = "Form4";
            Text = "Form4";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button7;
        private ComboBox comboBox1;
        private TextBox text_insert;
        private TextBox text_column;
        private Label label2;
        private Label label3;
        private Button button1;
        private Button button2;
        private DataGridView dataGridView1;
        private Button button3;
        private Label label4;
        private Label label5;
        private TextBox text_column1;
        private TextBox text_update;
        private Label label6;
        private TextBox text_update_ID;
        private Button button4;
        private Label label8;
        private TextBox text_delete;
    }
}