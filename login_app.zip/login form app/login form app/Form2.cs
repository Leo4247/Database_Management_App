﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login_form_app
{
    public partial class Form2 : Form
    {
        public string selectedValue;
        public Form2()
        {
            InitializeComponent();
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=EXPERTAA\BD;Initial Catalog=""Magazin Hitmarker"";Integrated Security=True;Encrypt=False;Trust Server Certificate=True");

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void FillDGV(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (String.Equals(value, "Angajatii companiei"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT Nume, Prenume, CNP, Sex, Adresa, Oras, Judet, NumeRaion, Salariu FROM Angajat JOIN Raion on Angajat.AngajatID = Raion.AngajatID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Carduri de Fidelitate"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT Card_Fidelitate.Nume, Card_Fidelitate.Prenume, Card_Fidelitate.Adresa, Card_Fidelitate.Oras, Card_Fidelitate.Judet, Card_Fidelitate.DataNastere, Email, Telefon, DataCreare, Angajat.Nume as 'Angajat.Nume' FROM Card_Fidelitate join Angajat on Card_Fidelitate.AngajatID = Angajat.AngajatID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }

                }
                if (String.Equals(value, "Categorii de produse"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeCategorie, NumeFurnizor, NumeRaion FROM Categorie join Produs on Categorie.CategorieID = Produs.CategorieID join Furnizor on Produs.FurnizorID = Furnizor.FurnizorID join Raion on Categorie.CategorieID = Raion.CategorieID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Furnizorii nostri"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeFurnizor, NumeCategorie , Adresa, Oras, Judet, Tara, DataIncheiereContract FROM Furnizor join Produs on Produs.FurnizorID = Furnizor.FurnizorID join Categorie on Categorie.CategorieID = Produs.CategorieID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Produsele din stoc"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeProdus, NumeCategorie, NumeRaion, NumeFurnizor, Pret, CantitateInStoc, DataFurnizare FROM Produs join Categorie on Produs.CategorieID = Categorie.CategorieID join Raion on Produs.RaionID = Raion.RaionID join Furnizor on Produs.FurnizorID = Furnizor.FurnizorID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Raioanele magazinului"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeRaion, Etaj, NumeCategorie, Nume, Prenume FROM Raion join Categorie on Raion.CategorieID = Categorie.CategorieID join Angajat on Raion.AngajatID = Angajat.AngajatID";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedValue = comboBox1.SelectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FillDGV(selectedValue);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FillDGV2(selectedValue);
        }
        private void FillDGV2(string value)
        {
            if (!string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(text_col.Text) && !string.IsNullOrEmpty(text_elem.Text))
            {
                if (String.Equals(value, "Angajatii companiei"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT Nume, Prenume, CNP, Sex, Adresa, Oras, Judet, NumeRaion, Salariu FROM Angajat JOIN Raion on Angajat.AngajatID = Raion.AngajatID WHERE "+text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Carduri de Fidelitate"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT Card_Fidelitate.Nume, Card_Fidelitate.Prenume, Card_Fidelitate.Adresa, Card_Fidelitate.Oras, Card_Fidelitate.Judet, Card_Fidelitate.DataNastere, Email, Telefon, DataCreare, Angajat.Nume as 'Angajat.Nume' FROM Card_Fidelitate join Angajat on Card_Fidelitate.AngajatID = Angajat.AngajatID WHERE " + text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }

                }
                if (String.Equals(value, "Categorii de produse"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeCategorie, NumeFurnizor, NumeRaion FROM Categorie join Produs on Categorie.CategorieID = Produs.CategorieID join Furnizor on Produs.FurnizorID = Furnizor.FurnizorID join Raion on Categorie.CategorieID = Raion.CategorieID WHERE "+text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Furnizorii nostri"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeFurnizor, NumeCategorie, Adresa, Oras, Judet, Tara, DataIncheiereContract FROM Furnizor join Produs on Produs.FurnizorID = Furnizor.FurnizorID join Categorie on Categorie.CategorieID = Produs.CategorieID WHERE "+text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Produsele din stoc"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeProdus, NumeCategorie, NumeRaion, NumeFurnizor, Pret, CantitateInStoc, DataFurnizare FROM Produs join Categorie on Produs.CategorieID = Categorie.CategorieID join Raion on Produs.RaionID = Raion.RaionID join Furnizor on Produs.FurnizorID = Furnizor.FurnizorID WHERE "+text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                if (String.Equals(value, "Raioanele magazinului"))
                {
                    try
                    {
                        conn.Open();
                        String query = "SELECT NumeRaion, Etaj, NumeCategorie, Nume , Prenume FROM Raion join Categorie on Raion.CategorieID = Categorie.CategorieID join Angajat on Raion.AngajatID = Angajat.AngajatID WHERE "+text_col.Text+"='"+text_elem.Text+"'";
                        SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                        DataTable dtable = new DataTable();
                        sda.Fill(dtable);
                        dataGridView1.DataSource = dtable;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
    }
}
