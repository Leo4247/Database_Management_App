﻿namespace login_form_app
{
    partial class FormSecret
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            text_luna = new TextBox();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            text_secret = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Ink Free", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(41, 9);
            label1.Name = "label1";
            label1.Size = new Size(367, 34);
            label1.TabIndex = 0;
            label1.Text = "Programul Secret de Concedieri";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Ink Free", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 81);
            label2.Name = "label2";
            label2.Size = new Size(249, 23);
            label2.TabIndex = 1;
            label2.Text = "Numele Angajatului Lunii este:";
            // 
            // text_luna
            // 
            text_luna.BorderStyle = BorderStyle.FixedSingle;
            text_luna.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            text_luna.Location = new Point(286, 79);
            text_luna.Name = "text_luna";
            text_luna.Size = new Size(164, 29);
            text_luna.TabIndex = 2;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLight;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Ink Free", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.DarkRed;
            button1.Location = new Point(113, 130);
            button1.Name = "button1";
            button1.Size = new Size(80, 38);
            button1.TabIndex = 5;
            button1.Text = "Salariu";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 301);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(448, 137);
            dataGridView1.TabIndex = 6;
            // 
            // text_secret
            // 
            text_secret.BackColor = SystemColors.MenuBar;
            text_secret.BorderStyle = BorderStyle.None;
            text_secret.Font = new Font("Ink Free", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            text_secret.ForeColor = Color.Red;
            text_secret.Location = new Point(12, 245);
            text_secret.Multiline = true;
            text_secret.Name = "text_secret";
            text_secret.Size = new Size(448, 50);
            text_secret.TabIndex = 7;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlLight;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Ink Free", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.DarkRed;
            button2.Location = new Point(113, 194);
            button2.Name = "button2";
            button2.Size = new Size(80, 38);
            button2.TabIndex = 8;
            button2.Text = "Raioane";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlLight;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Ink Free", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.DarkRed;
            button3.Location = new Point(259, 130);
            button3.Name = "button3";
            button3.Size = new Size(80, 38);
            button3.TabIndex = 9;
            button3.Text = "Carduri";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ControlLight;
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Ink Free", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.DarkRed;
            button4.Location = new Point(230, 188);
            button4.Name = "button4";
            button4.Size = new Size(140, 51);
            button4.TabIndex = 10;
            button4.Text = "Did Somebody say sale?";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // FormSecret
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(472, 450);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(text_secret);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Controls.Add(text_luna);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormSecret";
            Text = "FormSecret";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox text_luna;
        private Button button1;
        private DataGridView dataGridView1;
        private TextBox text_secret;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}