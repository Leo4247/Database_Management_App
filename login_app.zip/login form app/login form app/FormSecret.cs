﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace login_form_app
{
    public partial class FormSecret : Form
    {
        public FormSecret()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=EXPERTAA\BD;Initial Catalog=""Magazin Hitmarker"";Integrated Security=True;Encrypt=False;Trust Server Certificate=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_luna.Text))
            {
                try
                {
                    conn.Open();
                    String query = "SELECT Nume, Prenume FROM Angajat WHERE Salariu> (SELECT Salariu FROM Angajat WHERE Nume = '" + text_luna.Text + "') ";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                    text_secret.Text = "Acesti angajati au salariu mai mare decat angajatul lunii:";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                String query = "Select nume, prenume from angajat where angajatid = (SELECT angajat.AngajatID FROM Raion join Angajat on Angajat.AngajatID = Raion.AngajatID Group by Angajat.AngajatID Having Count(RaionID) > (SELECT Count(RaionID) FROM Raion join Angajat on Angajat.AngajatID = Raion.AngajatID Where Angajat.nume = '" + text_luna.Text + "')) ";
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);
                dataGridView1.DataSource = dtable;
                text_secret.Text = "Acesti angajati lucreaza la mai multe raioane decat angajatul lunii:";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_luna.Text))
            {
                try
                {
                    conn.Open();
                    String query = "SELECT Angajat.nume, Angajat.prenume FROM Angajat Where AngajatID = (SELECT Angajat.AngajatID FROM Angajat join Card_Fidelitate on Angajat.AngajatID = Card_Fidelitate.AngajatID Group by Angajat.AngajatID HAVING COUNT(Card_FidelitateID) > (SELECT count(Card_FidelitateID) FROM Angajat join Card_Fidelitate on Angajat.AngajatID = Card_Fidelitate.AngajatID Where angajat.nume = '" + text_luna.Text + "'))";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                    text_secret.Text = "Acesti angajati au facut mai multe carduri decat angajatul lunii:";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(text_luna.Text))
            {
                try
                {
                    conn.Open();
                    String query = "Select numeprodus from Produs where CantitateInStoc>3 and produs.raionid in (SELECT Produs.raionid FROM Produs Group by Produs.RaionID Having Produs.RaionID = (SELECT RaionID  FROM Raion join Angajat on Angajat.AngajatID = Raion.AngajatID Where Angajat.nume = '"+text_luna.Text +"'))";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);
                    dataGridView1.DataSource = dtable;
                    text_secret.Text = "Aceste produse sunt mai mult de 3 in stoc pe raioanele pe care lucreaza angajatul lunii:";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }
    }
}
